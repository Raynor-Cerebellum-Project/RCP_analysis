%LOADINI - loadata initialization module
%

% 	(c) Claudio G. Rey - 7:18AM  6/20/93



      ua       = ix2bc(index,10,length(ghpos));
      hhv      = diff(hhpos)/Ts'; 
      hvv      = diff(hvpos)/Ts'; 
      ghv      = diff(ghpos)/Ts'; 
      gvv      = diff(gvpos)/Ts'; 

%     define the max length of the data:

      N = min([length(fr);length(ghv)-lat]);


%     optional speedup definitions (require more menory):

%      ehp      = ghpos-hhpos;
%      ehv      = ghv-hhv;
%      nos      = cumsum(bc);

   NoofSegments       = length(M(:,1));