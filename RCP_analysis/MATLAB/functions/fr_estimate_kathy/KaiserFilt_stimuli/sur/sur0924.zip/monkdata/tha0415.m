
  disp( 'gaze vertical position')
  gvpos = array( :, 1) / 103.7 - 0;

  disp( 'vertical target position')
  vtar = array( :, 2) / 400 - 0;

  disp( 'gaze horizontal position')
  ghpos = array( :, 3) / 103.7 + 2;

  disp( 'horizontal target position')
  htar = array( :, 4) / 400 - 1.32;

  disp( 'head horizontal position')
  hhpos = array( :, 5) / 130 + 3.7;

  disp( 'head vertical position')
  hvpos = array( :, 6) / 140 + 17.3;

  disp( 'firing rate')
  vf    =  array( :, 7) /16 * 0.475;

  disp( 'tach')
  tach = array( :, 8) / 103.7 - 0;
 
  clear array

  filetype = 'calibrated',

  disp('Smoothing begins >>>>>>')

  fs = 1000; fc = 125;  B = fir1( 51, fc/fs*2);

  disp('Smoothing gaze ...')
  ghpos = filtfilt(B,1,ghpos);
  gvpos = filtfilt(B,1,gvpos);

  disp('Smoothing head ...')
  hhpos = filtfilt(B,1,hhpos);
  hvpos = filtfilt(B,1,hvpos);

  disp('Smoothing ends >>>>>>')
  disp(' ')

  Ts       = 1/1000;
  ns       = 1;
  lat      = 20;

  disp('Classification begins >>>>>>')

  disp('Computing markers ...')

% Choose right burst (20,9999) left burst would have been (-9999,-20);
% Toss out segments shorter than 25 ms ...
  M  = mark( diff( ghpos)*1000, 20, 9999, lat); M = cull( M, 25);

  clear fs fc

  disp('Classification ends >>>>>>')
  disp(' ')

  disp('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>')
  disp('Compute new firing rate name = fr')
  disp('This will take a while ......')
  fr = firing(index,600000,5/1000,1/10000,[-3,3],10);
  disp('<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<')
