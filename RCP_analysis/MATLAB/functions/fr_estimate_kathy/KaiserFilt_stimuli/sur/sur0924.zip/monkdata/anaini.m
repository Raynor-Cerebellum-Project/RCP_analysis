%ANAINI - analysis program first initialization module
%

% 	(c) Claudio G. Rey - 11:32AM  1/22/94


%  Variables to be save in a data file:

   variablestobesaved = 'fr ghpos gvpos htar vtar hhpos hvpos vf tach filetype M ns index Ts lat variablestobesaved';

%  Signal to be displayed if the plotdata file is destroyed:

   basicdefaultsignal = 'ghpos';

%  Where to store dynamic parameters:

   dynaparfilename    = [userdir 'dynadata.mat'];

%  Where to store polynomial parameters:

   polyparfilename    = [userdir 'polydata.mat'];

%  Where to store multiple bias parameters:

   mbiasparfilename   = [userdir 'mbiasdata.mat'];

%  Where to store polynomial parameters:

   vanparfilename     = [userdir 'vandata.mat'];

%  Where to store thresholding info:

   threshparfilename  = [userdir 'thshdata.mat'];

%  Where to store plotting and signalling choices:

   plotfilename    = [userdir 'plotdata.mat'];
