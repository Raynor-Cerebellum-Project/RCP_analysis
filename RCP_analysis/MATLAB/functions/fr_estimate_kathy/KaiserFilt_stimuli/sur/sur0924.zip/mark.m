function M = mark(x,xmin,xmax,latency)
%
%	M = mark(x,xmin,xmax,latency)
%
%

%	Claudio Rey - 12:25PM  1/5/93

   ix = 1:length(x);
   flag(ix) = abs(sign(x(ix)-xmin)+sign(x(ix)-xmax));
   M = fl2mx( flag)-latency;

end