%ANALYSIS - load and apply interactive analysis to session
%

% 	(c) Claudio G. Rey - 2:42PM  8/9/93
% 	modified Kathleen E. Cullen 10/21/93
%	modified C.G.R. -6:51PM  1/25/94 to add multiple bias option

%  load user directory


   if exist( 'userdir') == 1, 
      str = input(['Enter user directory: [' userdir ']: '],'s');
      if isempty( str) ~= 1, userdir = str; end
   else
      userdir = input(['Enter user directory: '],'s');
   end
   userdir = deblank( userdir);

%  DOS specific call:

   if userdir( length( userdir)) ~= '\', userdir = [userdir '\']; end

%  Clear graphics, handles and saved markers

   eval('delete(    hdatadisplay);','1;'); 
   eval('delete( heditsignaldefs);','1;');
   eval('delete(       hdynamics);','1;');
   eval('delete(      hthreshold);','1;');
   eval('delete(     hpolynomial);','1;');
   clear heditstr Msave hdatadisplay heditsignaldefs hdynamics hthreshold hpolynomial

   hdatadisplay = figure('Name', 'Data Display', 'Position', [ 300, 300, 600, 500],'NumberTitle','off','Color',[0,0,.05]);

%  Load basic definitions:

   anaini;

%  Create color list:

   colorlist = 'yellow';
   colorlist = str2mat(colorlist,'magenta');
   colorlist = str2mat(colorlist,'cyan');
   colorlist = str2mat(colorlist,'red');
   colorlist = str2mat(colorlist,'green');
   colorlist = str2mat(colorlist,'blue');

%  Define signal definitions:

   [Signaldefinitions, Signals, Signaldescriptions] = listini; NoofSignals = length(Signals(:,1));

%  Load or define plotting definitions

   loadplot;

%  Load input file:

   if exist( 'fileload') == 1,
      char = input('Load new datafile? [n]: ','s');
      if isempty( char)~=1,
%        Load the data
         loaddata; 
      else
         replot
      end
   else
      loaddata;
   end

   disp('Loading menus ...')

   figure( hdatadisplay);

   hdata = uimenu( 'label', '&Data');

   uimenu( hdata,     'label',     '&Load Datafile', 'Callback', 'loaddata;')
   uimenu( hdata,     'label',     '&Save Datafile', 'Callback', 'savedata;')
   uimenu( hdata,     'label',   'Start Stich File', 'Callback', 'stichnew;')
   uimenu( hdata,     'label',  'Add to Stich File', 'Callback', 'stichadd;')
   uimenu( hdata,     'label',           '&Latency', 'Callback', 'getlat;')
   uimenu( hdata,     'label',        '&Clear Data', 'Callback', 'clear,clf;')
   
   hdecmx = uimenu('label','&<', 'Callback', 'decmx;');

   hincmx = uimenu('label','&>', 'Callback', 'incmx;');

   hsegments = uimenu('label','&Segments');

   uimenu( hsegments, 'label',   'Start with &First', 'Callback', 'begmx;')
   uimenu( hsegments, 'label',      'End with &Last', 'Callback', 'endmx;')
   uimenu( hsegments, 'label',   'Select by &Number', 'Callback', 'gotoseg;')
   uimenu( hsegments, 'label', 'Select by Loca&tion', 'Callback', 'gototime;')
   uimenu( hsegments, 'label',         'Select &All', 'Callback', 'ns=1:length(M(:,1));replot;')
   uimenu( hsegments, 'label',            '&Add new', 'Callback', 'addseg;')
   uimenu( hsegments, 'label',   '&Delete displayed', 'Callback', 'delseg;')
   uimenu( hsegments, 'label',      '&Edit location', 'Callback', 'edtseg;')
   uimenu( hsegments, 'label',          '&Undo last', 'Callback', 'if exist(''Msave'')==1,M=Msave;clear Msave;NoofSegments=length(M(:,1));replot;end;' )

   hdisplay = uimenu( 'label', 'Dis&play');

   uimenu( hdisplay, 'label',             '&Replot', 'Callback', 'replot;')
   uimenu( hdisplay, 'label',    '&Continuous time', 'Callback', 'if timebase~=''tim-'';timebase=''tim-'';replot;end;')
   uimenu( hdisplay, 'label',       'Stac&ked time', 'Callback', 'if timebase~=''stac'';timebase=''stac'';replot;end;')
   uimenu( hdisplay, 'label',            '&xy plot', 'Callback', 'if timebase~=''xvsy'';timebase=''xvsy'';replot;end;')
   uimenu( hdisplay, 'label',            'Zoom I&n', 'Callback', 'buffer = max([1,round(buffer/4)]);replot;')
   uimenu( hdisplay, 'label',           'Zoom Ou&t', 'Callback', 'buffer = buffer*4;replot;')
   uimenu( hdisplay, 'label',          'Show &Grid', 'Callback', 'grid;')
   uimenu( hdisplay, 'label', 'Co&lor Assignements', 'Callback', 'dispcol;')
   uimenu( hdisplay, 'label',     '&Set Axes Range', 'Callback', 'getaxis;')
   uimenu( hdisplay, 'label',     '&Autorange Axes', 'Callback', 'axis(''normal'');')
   uimenu( hdisplay, 'label',        '&Freeze Axes', 'Callback', 'axis(axis);')
  
   hmetrics = uimenu( 'label', '&Clip');

   uimenu( hmetrics, 'label', '&Beginning Values', 'Callback', 'clipdata( ''first'', data, M, Mx, NoofDisplayed, ns, Ts);')
   uimenu( hmetrics, 'label',       '&End Values', 'Callback', 'clipdata( ''last'', data, M, Mx, NoofDisplayed, ns, Ts);')
   uimenu( hmetrics, 'label',           '&Delta', 'Callback', 'clipdata( ''delta'', data, M, Mx, NoofDisplayed, ns, Ts);')
   uimenu( hmetrics, 'label',           'Ma&xima', 'Callback', 'clipdata( ''max'', data, M, Mx, NoofDisplayed, ns, Ts);')
   uimenu( hmetrics, 'label',           'Min&ima', 'Callback', 'clipdata( ''min'', data, M, Mx, NoofDisplayed, ns, Ts);')
   uimenu( hmetrics, 'label',           '&Mean', 'Callback', 'clipdata( ''mean'', data, M, Mx, NoofDisplayed, ns, Ts);')
   uimenu( hmetrics, 'label',        '&Locations', 'Callback', 'clipdata( ''location'', data, M, Mx, NoofDisplayed, ns, Ts);')
   uimenu( hmetrics, 'label',        '&Durations', 'Callback', 'clipdata( ''duration'', data, M, Mx, NoofDisplayed, ns, Ts);')
   uimenu( hmetrics, 'label',  'Segment &Numbers', 'Callback', 'clipdata( ''numbers'', data, M, Mx, NoofDisplayed, ns, Ts);')

   htools = uimenu( 'label', '&Tools');

   uimenu( htools, 'label', '&Polynomial Fit', 'Callback', 'getpoly;');
   uimenu( htools, 'label',    '&Dynamic Fit', 'Callback', 'getdyna;');
   uimenu( htools, 'label',      '&Mbias Fit', 'Callback', 'mbiasgui;');
   uimenu( htools, 'label',     '&Van''s Fit', 'Callback', 'getvan;');
   uimenu( htools, 'label',       'Si&ne Fit', 'Callback', 'var_set;');
   uimenu( htools, 'label',      '&Threshold', 'Callback', 'getthrs;');
   uimenu( htools, 'label','&Firing Rate Model', 'Callback', 'mod_var;');
   uimenu( htools, 'label', 'Define &Signals', 'Callback', 'getedit;');

   hstate = uimenu( 'label', 'St&ate');

   uimenu( hstate, 'label', '&Fast Eye', 'Callback', 'fasteye;');
   uimenu( hstate, 'label', '&Slow Eye', 'Callback', 'sloweye;');

   disp('Ready ...')
   
