function [v,w,ic] = dynfit( dynaparfilename, data, Ts, Mx, sp, mb);
%DYNFIT - Fit second signal in data from dynamics derived from the first signal.
%
%

%  (c) - Claudio G. Rey - 2:15PM  1/15/94

%
%  Load fit parameters from disk:

   [b, nk, f, o, p, FT, nin, nout, sp] = loaddyna( dynaparfilename, Ts);

%
%  See if the offset is an empty variable meaning that no offset is desired:

   if isempty( o) == 1, choice =1; else, choice = 2; end

%
%  Do fit:

   [b,nk,f,o,p,v,w,ic] = fitsegi( choice, data, Ts, Mx, b, nk, f, o, p, FT, 'v', sp);

%
%  Save fit parameters to disk:

   savedyna( dynaparfilename, b, nk, f, o, p, FT, nin, nout, sp);

end