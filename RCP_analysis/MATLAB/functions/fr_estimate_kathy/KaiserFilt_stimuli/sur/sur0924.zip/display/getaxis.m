%GETAXIS - Get an axis setting interactively from the user
%
%

% Claudio G. Rey - 8:33AM  6/29/93

   str      = numa2str( axis);
   editcall = 'axisspec=sscanf(get( heditstr(2),''String''),''%g'');if isempty(axisspec)~=1,axis(axisspec);end;';

   editstr;
