function Plotstr = plotmate( Plotlist, Signals, Signaldefinitions);
%PLOTMATE - 	Compute the list of plotting variables by matching the plotlist 
%		to the signals available using their defnitions.
%
%	Plotstr = plotmate( Plotlist, Signals, Signaldefinitions);
%

%  Claudio G. Rey - 8:40AM  7/28/93

   for j = 1:length(Plotlist(:,1)),

      for k = 1:length( Signals),
          if Plotlist( j, 1:3) == deblank(Signals( k, :)), str = deblank(Signaldefinitions( k, :)); end
      end
      if  j == 1,
         Plotstr = [str];
      else
         Plotstr = [Plotstr ',' str];
      end

   end

end