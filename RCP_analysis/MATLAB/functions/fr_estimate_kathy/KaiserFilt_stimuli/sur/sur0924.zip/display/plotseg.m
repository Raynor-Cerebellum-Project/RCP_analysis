function [data,Md,Mx] = plotseg( titl, M, ns, timebase, buffer, pan, Ts, colorlist, X1, X2, X3, X4, X5, X6, X7, X8, X9, X10, X11, X12, X13, X14, X15, X16)
%PLOTSEG - Plot server
%
%	[data,Md,Mx] = plotseg( titl, M, ns, timebase, buffer, pan, Ts, colorlist, X1, X2,...)
%

%  (c) Claudio G. Rey - 4:41PM  7/7/93


%  Call the data server to define the data to be plotted:
 
   t = '[data,Md,Mx]=dataseg(M,ns,timebase,buffer,pan,Ts';number=nargin-8;
   for k = 1:number, t = [t,',X',int2str(k)]; end, t = [t,');'];
   eval( t);

%  Plot the data:

   if nargin ~=7, 
      if timebase == 'xvsy',
         if floor(number/2)*2==2,
            plot( data(:,1), data(:,2), '.');
         elseif floor(number/2)*2==4,
            plot( data(:,1), data(:,2), '.', data(:,3), data(:,4), '.');
         elseif floor(number/2)*2==6,
            plot( data(:,1), data(:,2), '.', data(:,3), data(:,4), '.', data(:,5), data(:,6), '.');
         elseif floor(number/2)*2==8,
            plot( data(:,1), data(:,2), '.', data(:,3), data(:,4), '.', data(:,5), data(:,6), '.', data(:,7), data(:,8), '.');
         end
      else
         [mm,nn] = size( data);
         plot( data(:,1), data(:,2:nn));

%        Show Markers:

         axisdimensions = axis;

         if timebase == 'stac'
            for i = 1:length(ns);
               line(([Mx(i,1) Mx(i,1)])*Ts,[axisdimensions(3:4)],'color','w')
               line(([Mx(i,2) Mx(i,2)])*Ts,[axisdimensions(3:4)],'color','w')
            end
         else
            for i = 1:length(ns);
               line(([Mx(i,1) Mx(i,1)]+Md(1,1)-1)*Ts,[axisdimensions(3:4)],'color','w')
               line(([Mx(i,2) Mx(i,2)]+Md(1,1)-1)*Ts,[axisdimensions(3:4)],'color','w')
            end
         end
      end
   end
    
   Mns = ix2mx( ns);

   titl = [titl ' - '];

   for i = 1:length(Mns(:,1)),
      if Mns(i,2) == Mns(i,1),
         titl = [titl int2str(Mns(i,1)) ' - '];
      else
         titl = [titl int2str(Mns(i,1)) ':' int2str(Mns(i,2)) ' - '];
      end
   end

   title( titl);

end