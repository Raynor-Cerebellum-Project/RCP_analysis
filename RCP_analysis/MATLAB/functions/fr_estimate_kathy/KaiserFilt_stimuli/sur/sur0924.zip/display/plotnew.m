%PLOTNEW - prepare the plotting signal argument according to Plotlist
%
% This command procedure writes out a new title and signal list for plotting
%

% (c) - Claudio G. Rey - 8:40AM  7/28/93


   NoofDisplayed = length( Plotlist( :, 1));
   plotstr = plotmate( Plotlist, Signals, Signaldefinitions);
   displaytitle = [dataname ': ']; 
   for i = 1:NoofDisplayed, displaytitle = [displaytitle lower(Plotlist(i,1:3)) ' '];end

   replot;
