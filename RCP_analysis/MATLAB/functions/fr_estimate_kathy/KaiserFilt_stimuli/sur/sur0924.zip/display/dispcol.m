%DISPCOL - View color assignements
%
%

% (c) Claudio G. Rey - 12:52PM  7/1/93




      NoofDisplayed = length( Plotlist( :, 1));
      list = [Plotlist(1,:) ' - ' colorlist(1,:)];
      for k = 2:NoofDisplayed, list = [list '|' Plotlist( k, :) ' - ' colorlist(k-floor((k-1)/6)*6,:)]; end

      popcall = 'delete( hpoplist);clear hpoplist';

      poplist;

