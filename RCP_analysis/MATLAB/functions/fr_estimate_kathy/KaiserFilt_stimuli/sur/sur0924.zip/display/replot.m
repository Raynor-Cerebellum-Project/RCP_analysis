%REPLOT - replot data and clear popups
%
%

%	(c) Claudio G. Rey - 3:32PM  8/6/93

   figure(hdatadisplay);

   eval(['[data,Md,Mx] = plotseg( displaytitle, M, ns, timebase, buffer, pan, Ts, colorlist,' plotstr ');']);
   eval(['save ' userdir 'plotdata Signals Plotlist Signaldefinitions timebase buffer pan colorlist'])
   NoofDisplayed = length(Plotlist(:,1));

   eval( 'delete( heditstr );', '1;'); clear heditstr
   eval( 'delete( hpoplist );', '1;'); clear hpoplist
   eval( 'delete( hpoplist2);', '1;'); clear hpoplist2
