%LOADPLOT - load last chosen plot preferences
%
%

% 	(c) Claudio G. Rey - 11:41PM  6/18/93


   if exist( plotfilename) == 2,
      eval( ['load ' plotfilename;]);
   else
      Plotlist = basicdefaultsignal;
      timebase = 'tim-';
      buffer   =     50;
      pan      =      0;
   end  
