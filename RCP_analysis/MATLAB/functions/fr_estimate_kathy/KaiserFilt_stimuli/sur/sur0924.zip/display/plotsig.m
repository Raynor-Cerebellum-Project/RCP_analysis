%PLOTSIG - prepare the plotting signal argument according to plotlist
%
% This command procedure updates the plotting list and writes out
% a new title and signal list for plotting and finally replots the data;
%

%	(c) Claudio G. Rey - 12:53PM  7/1/93

      NoofDisplayed = length( Plotlist(:,1));
      k = 0;
      for i = 1:NoofDisplayed,
         if Plotlist( i, 1:3) == Signals( Signalno, 1:3), k = i; end
      end

      if k == 0, 
         if NoofDisplayed  < 8, 
            Plotlist( NoofDisplayed  + 1, 1:3) = Signals( Signalno, 1:3);
            NoofDisplayed  = NoofDisplayed  + 1;
         else
            disp('Can display up to 8 signals'); 
         end
      else
         if NoofDisplayed  ~= 1, 
            if k==1,
               Plotlist = Plotlist(   2:NoofDisplayed , 1:3);
            elseif k==NoofDisplayed ,
               Plotlist = Plotlist( 1:NoofDisplayed -1, 1:3);
            else
               Plotlist = [Plotlist( 1:k-1, 1:3);Plotlist( k+1:NoofDisplayed , 1:3)];
            end
            NoofDisplayed  = NoofDisplayed  - 1;
         end
      end

      plotnew;