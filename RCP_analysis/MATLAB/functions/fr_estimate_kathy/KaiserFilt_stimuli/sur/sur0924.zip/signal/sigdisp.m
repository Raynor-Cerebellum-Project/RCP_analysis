%  Synonym for dispnew;

   dispnew;
