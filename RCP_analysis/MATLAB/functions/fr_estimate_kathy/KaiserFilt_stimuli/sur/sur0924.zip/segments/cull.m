function newM = cull(M,N)
% CULL	Chops off segments smaller than N samples.
%
%	newM = chop(M,N)
%
%	newM	-	updated marker domain descriptor		
%

% (c) Claudio G. Rey 6:20PM  7/24/92

  ns = length(M(:,1));

  k = 0;
  for j = 1:ns,
     if (M(j,2)-M(j,1)) > N,
        k=k+1; newM(k,1:2) = M(j,1:2);
     end
  end
end