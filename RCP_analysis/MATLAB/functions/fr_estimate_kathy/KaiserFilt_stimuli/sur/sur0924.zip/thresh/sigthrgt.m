%SIGTHRGT - Act on choice from the user
%
%

% (c) Claudio G. Rey - 8:40PM  1/3/94

   if choice == 1
      str      = num2str(xmin);
      editcall = 'xmin = sscanf(get( heditstr(2),''String''),''%g'');';
      editstr;
   elseif choice == 2
      str      = num2str(xmax);
      editcall = 'xmax = sscanf(get( heditstr(2),''String''),''%g'');';
      editstr;
   elseif choice == 3
      str      = int2str(srchout);
      editcall = 'srchout = sscanf(get( heditstr(2),''String''),''%d'');';
      editstr;
   elseif choice == 4
      list2 = deblank(Signaldescriptions(1,:));
      for k = 2: NoofSignals,
         list2 = [list2 '|' deblank(Signaldescriptions(k,:))];
      end
      popcall2 = 'buf001=get(hpoplist2,''value'');signame=deblank(Signaldefinitions(buf002,:));';
      poplist2;
   elseif choice == 5
      eval(['M = xthresh(' signame ',M,ns,xmin,xmax,srchout);']);
      savethrs; replot;
   elseif choice == 6
      savethrs;
      if exist( 'heditstr')  == 1, delete( heditstr);  clear heditstr;  end
      if exist( 'hpoplist')  == 1, delete( hpoplist);  clear hpoplist;  end
      if exist( 'hpoplist2') == 1, delete( hpoplist2); clear hpoplist2; end
   elseif choice == 7
      if exist( 'heditstr')  == 1, delete( heditstr);  clear heditstr;  end
      if exist( 'hpoplist')  == 1, delete( hpoplist);  clear hpoplist;  end
      if exist( 'hpoplist2') == 1, delete( hpoplist2); clear hpoplist2; end
   end
