function clip( variable)
%clip( variable)
%
%

%
   save temp$$$$.tsv variable /ascii /tabs
   !c:\matlab\bin\clipit.exe temp$$$$.tsv

end