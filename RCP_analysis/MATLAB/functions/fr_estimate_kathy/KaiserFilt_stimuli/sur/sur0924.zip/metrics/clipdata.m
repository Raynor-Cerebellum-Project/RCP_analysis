function clipdata( choice, data, M, Mx, NoofDisplayed, Segmentnumbers, Ts)
%CLIPDATA - Copy selected data from each segment displayed to the clipboard
%
%

%	(c) Claudio G. Rey - 11:11AM  7/8/93
% 	modified Kathleen E. Cullen 10/21/93


   NoofSegments = length( Mx(   :, 1));
   Noofdata     = length( data( 1, :));

   dataindex    = Noofdata-NoofDisplayed+1:Noofdata;

   if     strcmp(deblank(choice),'max')==1,

      datatobeclipped = zeros( NoofSegments, NoofDisplayed);
      for k = 1:NoofSegments, 
         datatobeclipped( k, :) = max( data(Mx(k,1):Mx(k,2),dataindex) ); 
      end            

   elseif strcmp(deblank(choice),'min')==1,

      datatobeclipped = zeros( NoofSegments, NoofDisplayed);
      for k = 1:NoofSegments, 
         datatobeclipped( k, :) = min( data(Mx(k,1):Mx(k,2),dataindex) ); 
      end
   
   elseif strcmp(deblank(choice),'mean')==1,

      datatobeclipped = zeros( NoofSegments, NoofDisplayed);
      for k = 1:NoofSegments, 
         datatobeclipped( k, :) = mean( data(Mx(k,1):Mx(k,2),dataindex) ); 
      end
        
   elseif strcmp(deblank(choice),'first')==1,

     datatobeclipped = data(Mx(:,1),dataindex)

   elseif strcmp(deblank(choice),'last')==1,

   
  datatobeclipped = data(Mx(:,2),dataindex)

   elseif strcmp(deblank(choice),'delta')==1,

     datatobeclipped = data(Mx(:,2),dataindex) - data(Mx(:,1),dataindex)

   elseif strcmp(deblank(choice),'duration')==1,

     datatobeclipped = (Mx(:,2)-Mx(:,1))*Ts;
     
   elseif strcmp(deblank(choice),'location')==1,

     datatobeclipped = (M( Segmentnumbers, 2) + M( Segmentnumbers, 1))/2*Ts;
     
   elseif strcmp(deblank(choice),'numbers')==1,

     datatobeclipped = Segmentnumbers;
     

   end

   clip( datatobeclipped)

end

